Group Members:
Samuel Bonner		- Bonnersa
Nicholas Skinner	- Skinnern


How to run:
command line: 
python sentiment.py trainingSet.txt testSet.txt

